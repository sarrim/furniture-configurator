// function customRange(){
//   // $('input[type="range"]').next('output').css('border','1px solid red');
// };

// jQuery('input[type="range"]').on('input', function() {
// //  console.log( $(this).val() );
//   var thisInput = $(this),
//       thisInputValue = thisInput.val(),
//       thisInputOutput = thisInput.next("output");
  
// //  console.log( thisInputValue );
//   thisInputOutput.text( thisInputValue );
  
//   thisInputOutput.css( 'left', thisInputValue + '%');
// });
// var rangeMeter = document.getElementById('rangeMeter');
// var rangeValue = document.getElementById('rangeValue');
// document.getElementById('oneForty').addEventListener('click', function(){
//     rangeMeter.value = 140;
//     rangeValue.innerHTML = 140;
//     // console.log(rangeValue)
// });

// document.getElementById('oneSixty').addEventListener('click', function(){
//     rangeMeter.value = 160;
//     rangeValue.innerHTML = 160;
//     // console.log(rangeValue)
// });
//  oneEighty = document.getElementById('oneEighty')
//  console.log(oneEighty)
// document.getElementById('oneEighty').addEventListener('click', function(){
//     rangeMeter.value = 180;
//     rangeValue.innerHTML = 180;
//     // console.log(rangeValue)
// });
// document.getElementById('twoHundred').addEventListener('click', function(){
//     rangeMeter.value = 200;
//     rangeValue.innerHTML = 200;
//     // console.log(rangeValue)
// });

var app = document.getElementById("app");
// width btns
var widthBtns = document.querySelectorAll('.widthBtns');
widthBtns.forEach(function(btn){
    btn.addEventListener('click', function(){
        console.log(btn.id);
        app.contentWindow.postMessage(btn.id, '*');
        console.log(app)
    })
})
// colors
// var colors = document.querySelectorAll('.colors')
// colors.forEach((color) => {  
// color.addEventListener('click', function(){
//     console.log(color.id) 
//     app.contentWindow.postMessage(color.id, '*');
// })
// })

// colors row by row
$(document).ready(function() {
$(".colorRow1").click(function () {
$(".colorRow1").children().removeClass("tickmarkActive");
$(this).children().addClass("tickmarkActive");  
console.log(this.id) 
app.contentWindow.postMessage(this.id, '*');
});
});
// 
$(document).ready(function() {
$(".colorRow2").click(function () {
$(".colorRow2").children().removeClass("tickmarkActive");
$(this).children().addClass("tickmarkActive");
console.log(this.id) 
app.contentWindow.postMessage(this.id, '*');  
});
});
// 
$(document).ready(function() {
$(".colorRow3").click(function () {
$(".colorRow3").children().removeClass("tickmarkActive");
$(this).children().addClass("tickmarkActive");
console.log(this.id) 
app.contentWindow.postMessage(this.id, '*');   
});
});
// 
$(document).ready(function() {
$(".colorRow4").click(function () {
$(".colorRow4").children().removeClass("tickmarkActive");
$(this).children().addClass("tickmarkActive");
console.log(this.id) 
app.contentWindow.postMessage(this.id, '*');   
});
});  
//    
$(document).ready(function() {
$(".colorRow5").click(function () {
$(".colorRow5").children().removeClass("tickmarkActive");
$(this).children().addClass("tickmarkActive");
console.log(this.id) 
app.contentWindow.postMessage(this.id, '*');   
});
});            